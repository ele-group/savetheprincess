<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXEvent; 
use php\gui\event\UXWindowEvent; 


class Download extends AbstractForm
{

    /**
     * @event label_title.destroy 
     */
    function doLabel_titleDestroy(UXEvent $event = null)
    {    
        
    }

    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        
    }


}
