0<?php
namespace app\forms;

use game\Jumping;
use php\jsoup\Elements;
use php\gui\framework\AbstractForm;
use php\gui\event\UXKeyEvent; 
use php\gui\event\UXMouseEvent; 
use php\game\event\UXCollisionEvent; 
use action\Score; 
use action\Element; 
use php\gui\event\UXEvent; 
use action\Animation; 
use game\Jumping; 


class Scene4 extends AbstractForm
{



    /**
     * @event timer.destroy 
     */
    function doTimerDestroy(UXEvent $e = null)
    {    
        
    }






















































































}
