<?php
namespace app\forms;

use php\gui\framework\AbstractForm;
use php\gui\event\UXMouseEvent; 


class Menu extends AbstractForm
{
    /**
     * @event buttonImg_exit.mouseDown-Left 
     */
    function doButtonImg_exitMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event button_start.mouseDown-Left 
     */
    function doButton_startMouseDownLeft(UXMouseEvent $e = null)
    {    
        
    }
}
